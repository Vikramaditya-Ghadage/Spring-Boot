package com.code.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.code.demo.model.WeatherResponse;
import com.code.demo.service.WeatherService;

@RestController
public class WeatherController {

    @Autowired
    private WeatherService weatherService;

    @GetMapping("/weather/forecast")
    public WeatherResponse getWeatherForecast(@RequestParam String city) {
        return weatherService.getWeatherForecast(city);
    }
}
