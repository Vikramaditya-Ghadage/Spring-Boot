package com.code.demo.model;


import java.time.LocalDate;

public class WeatherForecast {
    private LocalDate date;
    private double highTemp;
    private double lowTemp;
    private String recommendation;

    public WeatherForecast(LocalDate date, double highTemp, double lowTemp, String recommendation) {
        this.date = date;
        this.highTemp = highTemp;
        this.lowTemp = lowTemp;
        this.recommendation = recommendation;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public double getHighTemp() {
        return highTemp;
    }

    public void setHighTemp(double highTemp) {
        this.highTemp = highTemp;
    }

    public double getLowTemp() {
        return lowTemp;
    }

    public void setLowTemp(double lowTemp) {
        this.lowTemp = lowTemp;
    }

    public String getRecommendation() {
        return recommendation;
    }

    public void setRecommendation(String recommendation) {
        this.recommendation = recommendation;
    }
}
