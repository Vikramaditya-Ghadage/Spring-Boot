package com.code.demo.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.code.demo.model.OpenWeatherMapResponse;
import com.code.demo.model.WeatherForecast;
import com.code.demo.model.WeatherResponse;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class WeatherService {

    @Value("${weather.api.url}")
    private String apiUrl;

    @Value("${weather.api.key}")
    private String apiKey;

    private final RestTemplate restTemplate = new RestTemplate();

    public WeatherResponse getWeatherForecast(String city) {
        String url = String.format(apiUrl, city, apiKey);
        System.out.println(url);
        OpenWeatherMapResponse apiResponse = restTemplate.getForObject(url, OpenWeatherMapResponse.class);
        System.out.println(apiResponse);

        if (apiResponse == null) {
            throw new RuntimeException("Failed to fetch weather data");
        }

        List<WeatherForecast> forecasts = new ArrayList<>();
        for (OpenWeatherMapResponse.WeatherData data : apiResponse.getList()) {
            LocalDate date = LocalDate.parse(data.getDtTxt().split(" ")[0]);

            double highTemp = data.getMain().getTempMax();
            double lowTemp = data.getMain().getTempMin();
            String recommendation = getRecommendation(data);

            forecasts.add(new WeatherForecast(date, highTemp, lowTemp, recommendation));
        }

        WeatherResponse response = new WeatherResponse();
        response.setCity(apiResponse.getCity().getName());
        response.setForecasts(forecasts);
        return response;
    }

    private String getRecommendation(OpenWeatherMapResponse.WeatherData data) {
        StringBuilder recommendation = new StringBuilder();

        if (data.getWeather().stream().anyMatch(w -> w.getMain().equalsIgnoreCase("Rain"))) {
            recommendation.append("Carry umbrella. ");
        }
        if (data.getMain().getTempMax() > 40) {
            recommendation.append("Use sunscreen lotion. ");
        }
        if (data.getWind().getSpeed() > 10) {
            recommendation.append("It’s too windy, watch out! ");
        }
        if (data.getWeather().stream().anyMatch(w -> w.getMain().equalsIgnoreCase("Thunderstorm"))) {
            recommendation.append("Don’t step out! A Storm is brewing! ");
        }

        return recommendation.toString().trim();
    }
}
