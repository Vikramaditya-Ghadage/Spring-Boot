package com.code.demo.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OpenWeatherMapResponse {

    private City city;
    private List<WeatherData> list;

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public List<WeatherData> getList() {
        return list;
    }

    public void setList(List<WeatherData> list) {
        this.list = list;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class City {
        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class WeatherData {
        private Main main;
        private List<Weather> weather;
        private Wind wind;
        @JsonProperty("dt_txt")
        private String dtTxt;

        public Main getMain() {
            return main;
        }

        public void setMain(Main main) {
            this.main = main;
        }

        public List<Weather> getWeather() {
            return weather;
        }

        public void setWeather(List<Weather> weather) {
            this.weather = weather;
        }

        public Wind getWind() {
            return wind;
        }

        public void setWind(Wind wind) {
            this.wind = wind;
        }

        public String getDtTxt() {
            return dtTxt;
        }

        public void setDtTxt(String dtTxt) {
            this.dtTxt = dtTxt;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Main {
            @JsonProperty("temp_max")
            private double tempMax;
            @JsonProperty("temp_min")
            private double tempMin;

            public double getTempMax() {
                return tempMax;
            }

            public void setTempMax(double tempMax) {
                this.tempMax = tempMax;
            }

            public double getTempMin() {
                return tempMin;
            }

            public void setTempMin(double tempMin) {
                this.tempMin = tempMin;
            }
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Weather {
            private String main;

            public String getMain() {
                return main;
            }

            public void setMain(String main) {
                this.main = main;
            }
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Wind {
            private double speed;

            public double getSpeed() {
                return speed;
            }

            public void setSpeed(double speed) {
                this.speed = speed;
            }
        }
    }
}
