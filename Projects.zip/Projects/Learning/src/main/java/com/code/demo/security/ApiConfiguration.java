package com.code.demo.security;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;



//@EnableWebSecurity 
//WebSecurityConfigurerAdapter is deprecated after spring security 5.7

@Configuration
@EnableMethodSecurity   // -- you can use this when you are using @PreAuthorize("hasRole('ADMIN')") at method level
public class ApiConfiguration {
	
//	@Autowired
//	CustomUserDetails customUserDetails;
	
	
//	@Bean
//    public AuthenticationManager authenticationManagerBean(AuthenticationConfiguration  authenticationConfiguration) throws Exception {
//        return authenticationConfiguration.getAuthenticationManager();
//    }
//	

	@Bean
	public PasswordEncoder passwordEncoder()
	{
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	public UserDetailsService userDetailsService()
	{
		UserDetails normal_user= User.withUsername("zahir").
				password(passwordEncoder().encode("1234")).roles("NORMAL").build();
		
		UserDetails admin_user= User.withUsername("vikram").
				password(passwordEncoder().encode("1234")).roles("ADMIN").build();
		
		InMemoryUserDetailsManager manager=new InMemoryUserDetailsManager(normal_user,admin_user);
		
		return manager;
		
		//return new CustomUserDetails();
		
	}
	
	@SuppressWarnings("removal")
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf().disable()
				.authorizeHttpRequests()
				.requestMatchers("/api/admin/**").hasRole("ADMIN")
				.requestMatchers("/api/normal/**").hasRole("NORMAL")
				.requestMatchers("/api/public/**").permitAll()
//				.anyRequest().permitAll()
				.anyRequest().authenticated()
				.and()
				.formLogin().permitAll()
				.and()
				.logout().permitAll();
        
		return http.build();
    }
	
}


