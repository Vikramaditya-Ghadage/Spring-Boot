package com.code.demo.controller;

import org.springframework.web.bind.annotation.RestController;

import com.code.demo.configuration.LearningConfiguration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;


@RestController
public class LearningController {
	
	@Autowired
	LearningConfiguration cong;
	
	
	@GetMapping("/learning")
	public String requestMethodName()
	{
		return "Learning";
	}
	
	@GetMapping("/learning-con")
	public LearningConfiguration config()
	{
		return cong;
	}
	

}
