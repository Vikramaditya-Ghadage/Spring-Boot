package com.code.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.code.demo.service.NumberService;

@RestController
public class NumberController {

    @Autowired
    private NumberService numberService;

    @GetMapping("/start-threads")
    public String startThreads() {
    	numberService.printEvenNumbers();
        numberService.printOddNumbers();
        numberService.printPrimeNumbers();
        return "Threads started";
    }
}
