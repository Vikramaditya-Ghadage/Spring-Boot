package com.code.demo.multithreading;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.code.demo.service.AsyncService;

@RestController
public class AsyncController {
	
		@Autowired
		private AsyncService asyncService;

		@GetMapping("/start-async-task")
		public String startAsyncTask() {
		    asyncService.performAsyncTask();
		    return "Task started";
		}
}
