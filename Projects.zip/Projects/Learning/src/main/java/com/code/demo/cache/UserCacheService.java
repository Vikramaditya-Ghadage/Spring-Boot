package com.code.demo.cache;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.code.demo.model.User;
import com.code.demo.repository.UserRepository;

@Service
public class UserCacheService {
	@Autowired
	UserRepository repo;
     //The @Cacheable annotation on the findById method tells Spring to cache the result of the method call.
    @Cacheable("userCache")
    public Optional<User> getStudentById(Long id) {
        
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return repo.findById(id);
    }
}

