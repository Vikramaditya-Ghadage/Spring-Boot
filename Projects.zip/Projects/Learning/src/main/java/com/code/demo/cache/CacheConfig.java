package com.code.demo.cache;
import org.ehcache.config.builders.CacheConfigurationBuilder;
import org.ehcache.config.builders.CacheManagerBuilder;
import org.ehcache.config.builders.ResourcePoolsBuilder;
import org.springframework.cache.annotation.EnableCaching;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.code.demo.model.User;

import org.ehcache.jsr107.Eh107Configuration;
import org.springframework.cache.jcache.JCacheCacheManager;


import javax.cache.Caching;
import javax.cache.spi.CachingProvider;
import javax.cache.CacheManager;
import javax.cache.configuration.MutableConfiguration;

@Configuration
@EnableCaching
public class CacheConfig {

    @Bean
    public JCacheCacheManager cacheManager() {
        CachingProvider cachingProvider = Caching.getCachingProvider();
        CacheManager cacheManager = cachingProvider.getCacheManager();
        cacheManager.createCache("userCache", Eh107Configuration.fromEhcacheCacheConfiguration(
                org.ehcache.config.builders.CacheConfigurationBuilder.newCacheConfigurationBuilder(
                        Long.class, User.class, org.ehcache.config.builders.ResourcePoolsBuilder.heap(100))
//                        .withExpiry(org.ehcache.expiry.Expirations.timeToLiveExpiration(java.time.Duration.ofSeconds(600)))
                        .build()));
        return new JCacheCacheManager(cacheManager);
    }
}
