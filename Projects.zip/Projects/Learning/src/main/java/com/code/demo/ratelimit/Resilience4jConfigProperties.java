package com.code.demo.ratelimit;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.Map;

@Component
@ConfigurationProperties(prefix = "resilience4j")
public class Resilience4jConfigProperties {

    private Map<String, CircuitBreakerConfig> circuitbreaker;
    private Map<String, RetryConfig> retry;
    private Map<String, RateLimiterConfig> ratelimiter;
    private Map<String, BulkheadConfig> bulkhead;

    // Getters and setters

    public Map<String, CircuitBreakerConfig> getCircuitbreaker() {
        return circuitbreaker;
    }

    public void setCircuitbreaker(Map<String, CircuitBreakerConfig> circuitbreaker) {
        this.circuitbreaker = circuitbreaker;
    }

    public Map<String, RetryConfig> getRetry() {
        return retry;
    }

    public void setRetry(Map<String, RetryConfig> retry) {
        this.retry = retry;
    }

    public Map<String, RateLimiterConfig> getRatelimiter() {
        return ratelimiter;
    }

    public void setRatelimiter(Map<String, RateLimiterConfig> ratelimiter) {
        this.ratelimiter = ratelimiter;
    }

    public Map<String, BulkheadConfig> getBulkhead() {
        return bulkhead;
    }

    public void setBulkhead(Map<String, BulkheadConfig> bulkhead) {
        this.bulkhead = bulkhead;
    }

    public static class CircuitBreakerConfig {
        private boolean registerHealthIndicator;
        private int slidingWindowSize;
        private int minimumNumberOfCalls;
        private Duration waitDurationInOpenState;
        private float failureRateThreshold;

        // Getters and setters
    }

    public static class RetryConfig {
        private int maxAttempts;
        private Duration waitDuration;
        private Class<? extends Throwable>[] retryExceptions;

        // Getters and setters
    }

    public static class RateLimiterConfig {
        private int limitForPeriod;
        private Duration limitRefreshPeriod;

        // Getters and setters
    }

    public static class BulkheadConfig {
        private int maxConcurrentCalls;
        private Duration maxWaitDuration;

        // Getters and setters
    }
}

