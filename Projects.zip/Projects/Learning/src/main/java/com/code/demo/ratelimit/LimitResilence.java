package com.code.demo.ratelimit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import io.github.resilience4j.bulkhead.annotation.Bulkhead;


@RestController
public class LimitResilence {

    @Autowired
    private Resilience4jConfigProperties resilience4jConfig;

    @GetMapping("/example")
    @CircuitBreaker(name = "exampleCircuitBreaker", fallbackMethod = "fallbackCircuitBreaker")
    @Retry(name = "exampleRetry", fallbackMethod = "fallbackRetry")
    @RateLimiter(name = "exampleRateLimiter", fallbackMethod = "fallbackRateLimiter")
    @Bulkhead(name = "exampleBulkhead", fallbackMethod = "fallbackBulkhead")
    public String exampleEndpoint() {
        // Your combined resilient code here
        return "Success!";
    }

    // Fallback methods
    public String fallbackCircuitBreaker(Exception e) {
        return "Circuit Breaker fallback response due to: " + e.getMessage();
    }

    public String fallbackRetry(Exception e) {
        return "Retry fallback response due to: " + e.getMessage();
    }

    public String fallbackRateLimiter(Exception e) {
        return "Rate Limiter fallback response due to: " + e.getMessage();
    }

    public String fallbackBulkhead(Exception e) {
        return "Bulkhead fallback response due to: " + e.getMessage();
    }
}

