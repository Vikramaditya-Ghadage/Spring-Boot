//package com.code.demo.kafka;
//
//
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.stereotype.Service;
//
//@Service
//public class KafkaProducerService {
//
//    private final KafkaTemplate<String, String> kafkaTemplate;
//
//    // Inject KafkaTemplate for producing messages
//    public KafkaProducerService(KafkaTemplate<String, String> kafkaTemplate) {
//        this.kafkaTemplate = kafkaTemplate;
//    }
//
//    // Method to send a message to Kafka
//    public void sendMessage(String message) {
//        kafkaTemplate.send("my-topic", message);
//    }
//}
