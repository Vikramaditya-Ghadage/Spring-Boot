package com.code.demo.multithreading;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    @Async("taskExecutor")
    public void processOrder(String orderId) {
        System.out.println("Processing order: " + orderId + " - " + Thread.currentThread().getName());
        try {
            // Simulate order processing time
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println("Completed order: " + orderId + " - " + Thread.currentThread().getName());
    }
}
