package com.code.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.code.demo.model.User;
import com.code.demo.service.UserService;

@RestController
@RequestMapping("/api/public/user")
public class UserController {
	
	@Autowired
	UserService service;
	
	@PostMapping
	public ResponseEntity<User> saveUser(@RequestBody User obj)
	{
		User user=service.saveUser(obj);
		return ResponseEntity.status(HttpStatus.CREATED).body(user);
	}
	

}
