package com.code.demo.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RestController

public class BankController {
	
	@GetMapping("/api/public/main")
	public String mainPage() {
		return "Welcome To Main Page";
	}
	
	@GetMapping("/api/public/account")
	public String getAccount() {
		return "Welcome Vikram";
	}
	
	@PreAuthorize("hasRole('NORMAL')")
	@GetMapping("/api/normal/update")
	public String getUpdate() {
		return "Please download below update";
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/api/admin/balance")
	public String checkBalance() {
		return "Balance:"+1000;
	}
}
