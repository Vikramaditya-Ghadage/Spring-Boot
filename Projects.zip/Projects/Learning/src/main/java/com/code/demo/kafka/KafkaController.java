//package com.code.demo.kafka;
//
//import com.example.kafkaexample.service.KafkaProducerService;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RestController;
//

//# Start Zookeeper (Kafka dependency)
//bin/zookeeper-server-start.sh config/zookeeper.properties

//# Start Kafka server
//bin/kafka-server-start.sh config/server.properties


//@RestController
//public class KafkaController {
//
//    private final KafkaProducerService kafkaProducerService;
//
//    // Inject the producer service
//    public KafkaController(KafkaProducerService kafkaProducerService) {
//        this.kafkaProducerService = kafkaProducerService;
//    }
//
//    // Endpoint to send a message to Kafka
//    @GetMapping("/send")
//    public String sendMessage() {
//        kafkaProducerService.sendMessage("Hello Kafka!");
//        return "Message sent to Kafka!";
//    }
//}



