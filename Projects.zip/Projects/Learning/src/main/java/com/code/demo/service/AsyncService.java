package com.code.demo.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class AsyncService {

    @Async("taskExecutor")
    public void performAsyncTask() {
        System.out.println("Executing task in thread: " + Thread.currentThread().getName());
        // Add your task logic here
    }
}
