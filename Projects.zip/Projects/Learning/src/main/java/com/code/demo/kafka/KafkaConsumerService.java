//package com.code.demo.kafka;
//
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.stereotype.Service;
//
//@Service
//public class KafkaConsumerService {
//
//    // Method that listens for messages from the Kafka topic
//    @KafkaListener(topics = "my-topic", groupId = "test-group")
//    public void listen(String message) {
//        System.out.println("Received message: " + message);
//    }
//}

