package com.code.demo.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class NumberService {

    @Async("taskExecutor")
    public void printEvenNumbers() {
        for (int i = 2; i <= 50; i += 2) {
            System.out.println("Even: " + i + " - Thread: " + Thread.currentThread().getName());
            try {
                Thread.sleep(500);  // Sleep to simulate delay
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    @Async("taskExecutor")
    public void printOddNumbers() {
        for (int i = 1; i <= 49; i += 2) {
            System.out.println("Odd: " + i + " - Thread: " + Thread.currentThread().getName());
            try {
                Thread.sleep(500);  // Sleep to simulate delay
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    @Async("taskExecutor")
    public void printPrimeNumbers() {
        for (int i = 2; i <= 50; i++) {
            if (isPrime(i)) {
                System.out.println("Prime: " + i + " - Thread: " + Thread.currentThread().getName());
                try {
                    Thread.sleep(500);  // Sleep to simulate delay
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    private boolean isPrime(int num) {
        if (num <= 1) return false;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) return false;
        }
        return true;
    }
}
