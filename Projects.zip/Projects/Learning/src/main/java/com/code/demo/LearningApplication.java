package com.code.demo;

import org.springframework.boot.SpringApplication;


import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningApplication {


	public static void main(String[] args) {
		SpringApplication.run(LearningApplication.class, args);
	}
	
//	@Bean
//    public FilterRegistrationBean<RateLimitFilter> loggingFilter() {
//        FilterRegistrationBean<RateLimitFilter> registrationBean = new FilterRegistrationBean()<>();
//
//        registrationBean.setFilter(new RateLimitFilter());
//        registrationBean.addUrlPatterns("/api/*");
//
//        return registrationBean;
//    }
}
