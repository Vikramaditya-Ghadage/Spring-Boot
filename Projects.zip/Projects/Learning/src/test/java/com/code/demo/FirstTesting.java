package com.code.demo;

import static org.junit.jupiter.api.Assertions.*;


import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FirstTesting {

	@BeforeAll
	public static void beforeAll()   // class level that why added static
	{
		System.out.println("Before All Test cases");
	}
	
	@BeforeEach
	public void beforeEach()
	{
		System.out.println("Before Each Test");
	}
	
	@Test
	void testResult() {
		int no=5;
		int result = no*no;
		int expectedResult=25;
		System.out.println("Actual Result:"+result+" and Expected result:"+expectedResult);
	    assertEquals(expectedResult, result);
	}

	@Test
	void checkElement() {
		List<String> cloud = Arrays.asList("AWS","AZURE","GCP");
		boolean res=cloud.contains("GCP");
		System.out.println("Actual Result:"+res+" and Expected result:"+true);
	    assertEquals(true,res);
	}
	
//	@Test
//	void checkArray() {
//	   assertArrayEquals(new int[] {1,2,3},new int[] {1,2,3});
//	}
	
	@AfterEach
	public void afterEach()
	{
		System.out.println("After Each Test");
	}
	
	@AfterAll
	public static void afterAll()
	{
		System.out.println("After All Test cases");
	}
}
