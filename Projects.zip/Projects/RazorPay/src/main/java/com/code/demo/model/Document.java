package com.code.demo.model;

public class Document {

}
