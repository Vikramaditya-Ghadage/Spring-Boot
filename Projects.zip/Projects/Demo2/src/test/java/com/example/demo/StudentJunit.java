package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mockitoSession;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.example.demo.controller.StudentController;
import com.example.demo.model.Student;
import com.example.demo.service.StudentService;

class StudentJunit {
	
	@Mock
	StudentService service;
	
	@InjectMocks
	StudentController controller;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGetStudentById() {
		
		long id=1;
		Student s1=new Student(id,"Vikram",99);
		
		when(service.getStudentById(id)).thenReturn(s1);
		
		ResponseEntity<Student> response=controller.getStudentById(id);
		System.out.println("body:"+response.getBody());
		
		assertEquals(response.getBody().getId(),s1.getId());
		assertEquals(response.getBody().getName(),s1.getName());
		assertEquals(response.getBody().getMarks(),s1.getMarks());
		
	}

}
