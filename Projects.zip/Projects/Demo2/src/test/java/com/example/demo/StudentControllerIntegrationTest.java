package com.example.demo;



import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.junit.jupiter.api.Assertions.assertEquals;


//StudentControllerIntegrationTest class is an integration test. It uses @SpringBootTest to load 
//the complete Spring application context and MockMvc to make HTTP requests to the StudentController, 
//testing the controller's behavior and its interaction with the StudentService.

@SpringBootTest
@AutoConfigureMockMvc
public class StudentControllerIntegrationTest {


    @Autowired
    private MockMvc mockMvc;
    
    
    @Test
    public void testGetStudentById() throws Exception {
        // Prepare mock data
        long studentId = 1; // Assuming this ID exists in mock data

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/api/students/{id}", studentId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(studentId))
                .andExpect(MockMvcResultMatchers.jsonPath("$.name").value("Vikram"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.marks").value(99))
                .andReturn();

        // Print and verify response content
        String content = result.getResponse().getContentAsString();
        System.out.println("Response Content for specific Student: " + content);

        // Verify response fields using assertions
        assertEquals(MediaType.APPLICATION_JSON_VALUE, result.getResponse().getContentType());
        assertEquals(200, result.getResponse().getStatus());
        assertEquals("{\"id\":1,\"name\":\"Vikram\",\"marks\":99.0}", content); // Adjust as per your actual expected response JSON

    }
    
    
    @Test
    public void testGetAllStudents() throws Exception {
    	 MvcResult result = mockMvc.perform(MockMvcRequestBuilders.get("/api/students")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].id").value(1))
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].name").value("Vikram"))
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].marks").value(99))
                .andReturn();
                // Add more assertions based on your actual response structure
        
        String content = result.getResponse().getContentAsString();
        System.out.println("Response Content for All Students : " + content);
    }
    
    
//    @Test
//    public void testAddStudent() throws Exception {
//        String studentJson = "{\"id\": 1,\"name\": \"Vikram\", \"marks\": 99}";
//
//        mockMvc.perform(MockMvcRequestBuilders.post("/api/students")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content(studentJson))
//                .andExpect(MockMvcResultMatchers.status().isCreated());
//                // Add more assertions if needed
//    }
    
    
    @Test
    public void testDeleteStudentById() throws Exception {
        long studentId = 152; // Assuming this ID exists in mock data

        mockMvc.perform(MockMvcRequestBuilders.delete("/api/students?id=", studentId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk());
                // Add more assertions if needed
        
    }


}
