package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.controller.StudentController;
import com.example.demo.service.StudentService;

@WebMvcTest(StudentController.class)
@AutoConfigureMockMvc
public class StudentControllerTest {

//    @Autowired
//    private MockMvc mockMvc;
//
//    @MockBean
//    private StudentService studentService;
//
//    @Test
//    public void testGetAllStudents() throws Exception {
//        // Prepare mock data
//        List<Student> students = Arrays.asList(
//                new Student(1L, "John Doe"),
//                new Student(2L, "Jane Smith")
//        );
//
//        // Mock the service method
//        when(studentService.getAllStudents()).thenReturn(students);
//
//        // Perform GET request
//        mockMvc.perform(get("/students")
//                .contentType(MediaType.APPLICATION_JSON))
//                .andExpect(status().isOk())
//                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
//                .andExpect(jsonPath("$.length()").value(students.size())) // Assuming JSON array
//                .andExpect(jsonPath("$[0].name").value("John Doe")) // Validate content
//                .andExpect(jsonPath("$[1].name").value("Jane Smith"));
//    }
}