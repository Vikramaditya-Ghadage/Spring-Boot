package com.example.demo.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;
import com.example.demo.service.StudentService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController
@RequestMapping("/api/students")
public class StudentController {
	
	@Autowired
	StudentService service;
	
	@GetMapping
	public ResponseEntity<List<Student>> getAllStudents()
	{
		List<Student> stu_list=service.getAllStudents();
		return ResponseEntity.status(HttpStatus.OK).body(stu_list);
	}
	
	//http://127.0.0.1:8080/api/students/1
	@GetMapping("/{id}")
	public ResponseEntity<Student> getStudentById(@PathVariable long id)
	{
		Student stu=service.getStudentById(id);
		return ResponseEntity.ok(stu);
	}
	
	@PostMapping
	public ResponseEntity<Student> addStudent(@RequestBody Student stu)
	{
		Student addedStudent=service.addStudent(stu);
		return ResponseEntity.status(HttpStatus.CREATED).body(addedStudent);
	}
	
	//http://127.0.0.1:8080/api/students?id=102
	@DeleteMapping
	public ResponseEntity<String> deleteStudent(@RequestParam long id)
	{
		System.out.println(id);
		service.deletStudent(id);
		return ResponseEntity.status(HttpStatus.OK).body("Student deleted Sucessfully:");
	}
	
}
