package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Department;
import com.example.demo.repository.DepartmentRepo;

@Service
public class DepartmentService {
	
	@Autowired
	DepartmentRepo repo;
	
	public List<Department> getallDepartments()
	{
		return repo.findAll();
	}
	
	public Department getDepartment(long dept_id)
	{
		Optional<Department> dep=repo.findById(dept_id);
//		if(dep.isPresent())
			return dep.get();
//		else
//			return 
	}

}
