package com.example.demo.model;

import org.hibernate.annotations.ManyToAny;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;

@Entity
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long emp_id;
	
	private String name;
	
	@ManyToAny
	@JoinColumn(name="dept_id")
	private Department dept;

	public long getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(long emp_id) {
		this.emp_id = emp_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public Employee(long emp_id, String name, long dept_id) {
		super();
		this.emp_id = emp_id;
		this.name = name;
		this.dept = new Department(dept_id,"");
	}

	public Employee() {
		super();
	}
	
	

}
