package com.example.demo.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
//import reactor.core.publisher.Mono;

import com.example.demo.model.Student;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;


@RestController
@RequestMapping("/api/rest-template")
public class RestTemplateController {
	
	@GetMapping
	public ResponseEntity<List<Student>> getAllStudentsWithRestTemplates() {
		System.out.println("Rest template-called");
		String url="http://127.0.0.1:8080/api/students";
		RestTemplate template=new RestTemplate();
		List<Student> response=template.getForObject(url, List.class);
		return ResponseEntity.status(HttpStatus.OK).body(response);
		
	}
	
//	@GetMapping
//	public Mono<ResponseEntity<List<Student>>> getAllStudentsWithWebClient() {
//		System.out.println("Rest template-called");
//		String url="http://127.0.0.1:8080/api/students";
//		 return webClient.get()
//	                .uri(url)  // Relative URI, as baseUrl is already set
//	                .retrieve()
//	                .bodyToMono(List.class)  // Convert the response body to Mono<List<Student>>
//	                .map(response -> ResponseEntity.status(HttpStatus.OK).body(response))  // Map response to ResponseEntity
//	                .defaultIfEmpty(ResponseEntity.status(HttpStatus.NOT_FOUND).build());  // Handle empty responses
//	    }
//		
//	}
}
