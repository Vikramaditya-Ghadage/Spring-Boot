package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepo;

@Service
public class StudentService {
	
	@Autowired
	StudentRepo repo;
	
	public List<Student> getAllStudents()
	{
		return repo.findAll();
	}
	
	public Student getStudentById(long id)
	{
		Optional<Student> stu=repo.findById(id);
		if(stu.isPresent())
			return stu.get();
		throw new RuntimeException("Student id not found:"+id);
		
	}
	
	public void deletStudent(long id)
	{
		Optional<Student> stu=repo.findById(id);
		if(stu.isPresent())
			repo.deleteById(id);
		else
		throw new RuntimeException("Student id not found:"+id);
				
	}
	
	public Student addStudent(Student obj)
	{
		return repo.save(obj);
	}

}
