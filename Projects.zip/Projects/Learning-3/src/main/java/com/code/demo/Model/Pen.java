package com.code.demo.Model;

public class Pen {

	private String type;
	private String Body;
	private String color;
	private int ink;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getBody() {
		return Body;
	}
	public void setBody(String body) {
		Body = body;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
	public Pen(String type, String body, String color,int ink) {
		super();
		this.type = type;
		Body = body;
		this.color = color;
		this.ink=ink;
	}
	public Pen() {
		super();
	}
	
	public void writePen()
	{
		Pen p1=new Pen("Fountain","Plastic","Red",100);
		
		String text="Hello World";
		int letter=100;
		try
		{
			
			if((ink-text.length())<0)
				throw new Exception("Ink finished");
			else
				ink-=text.length();
				System.out.println("Completed");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
			
	}
	
	public void fillInk(int unit)
	{
		if((ink+unit)<=100)
		ink+=unit;
		else
			ink=100;
			unit=100-ink;
			System.out.println("unit remaining:"+unit);
	}
	
}
