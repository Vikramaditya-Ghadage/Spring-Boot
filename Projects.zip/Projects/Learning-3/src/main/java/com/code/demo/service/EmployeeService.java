package com.code.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.code.demo.Model.Employee;
import com.code.demo.repo.EmployeeRepo;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepo repo;
	
	public List<Employee> getAllEMployee()
	{
		return repo.findAll();
	}
	

}
