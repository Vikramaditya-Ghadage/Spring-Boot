package com.code.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.code.demo.model.SalesInvoice;
import com.code.demo.repository.SalesInvoiceRepository;

@Service
public class SalesService {

    @Autowired
    private SalesInvoiceRepository salesInvoiceRepository;

    @Autowired
    private InventoryService inventoryService;

    public SalesInvoice createSalesInvoice(SalesInvoice salesInvoice) {
        inventoryService.updateStock(salesInvoice.getItemCode(), -salesInvoice.getQuantity());
        return salesInvoiceRepository.save(salesInvoice);
    }

    public SalesInvoice createSalesReturn(SalesInvoice salesReturn) {
        inventoryService.updateStock(salesReturn.getItemCode(), salesReturn.getQuantity());
        return salesInvoiceRepository.save(salesReturn);
    }

    public List<SalesInvoice> handleRejectedItems(Map<String, Integer> rejectedItems) {
        List<SalesInvoice> salesReturns = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : rejectedItems.entrySet()) {
            String itemCode = entry.getKey();
            int rejectedQuantity = entry.getValue();
            List<SalesInvoice> salesInvoices = salesInvoiceRepository.findByItemCodeOrderByIdAsc(itemCode);
            for (SalesInvoice invoice : salesInvoices) {
                if (rejectedQuantity <= 0) break;
                int returnQuantity = Math.min(rejectedQuantity, invoice.getQuantity());
                SalesInvoice salesReturn = new SalesInvoice(null, invoice.getCustomer(), "Sales Return",
                        itemCode, -returnQuantity, invoice.getUnitOfMeasure());
                salesReturns.add(createSalesReturn(salesReturn));
                rejectedQuantity -= returnQuantity;
            }
        }
        return salesReturns;
    }
}