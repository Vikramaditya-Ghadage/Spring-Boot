package com.code.demo.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.code.demo.exception.ResourceNotFoundException;
import com.code.demo.model.InventoryItem;
import com.code.demo.repository.InventoryItemRepository;

import java.util.List;

@Service
public class InventoryService {

    @Autowired
    private InventoryItemRepository inventoryItemRepository;

    public List<InventoryItem> getAllItems() {
        return inventoryItemRepository.findAll();
    }
    
    public InventoryItem addInventory(InventoryItem item) {
        return inventoryItemRepository.save(item);
    }

    public InventoryItem updateStock(String itemCode, int quantityChange) {
        InventoryItem item = inventoryItemRepository.findByItemCode(itemCode)
                .orElseThrow(() -> new ResourceNotFoundException("Item not found"));
        item.setQuantity(item.getQuantity() + quantityChange);
        return inventoryItemRepository.save(item);
    }
}