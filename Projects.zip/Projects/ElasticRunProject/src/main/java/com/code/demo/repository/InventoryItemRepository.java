package com.code.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.code.demo.model.InventoryItem;

import java.util.Optional;

public interface InventoryItemRepository extends JpaRepository<InventoryItem, Long> {
    Optional<InventoryItem> findByItemCode(String itemCode);
}