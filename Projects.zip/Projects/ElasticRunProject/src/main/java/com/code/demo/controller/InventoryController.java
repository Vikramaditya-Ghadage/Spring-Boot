package com.code.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.code.demo.model.InventoryItem;
import com.code.demo.service.InventoryService;

import java.util.List;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;
    @GetMapping
    public List<InventoryItem> getAllItems() {
        return inventoryService.getAllItems();
    }
    
    @PostMapping
    public ResponseEntity<InventoryItem> addInventory(@RequestBody InventoryItem item) {
    	inventoryService.addInventory(item);
        return ResponseEntity.status(HttpStatus.CREATED).body(item);
    }
    
}