package com.code.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.code.demo.model.SalesInvoice;
import com.code.demo.service.SalesService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/sales")
public class SalesController {

    @Autowired
    private SalesService salesService;

    @PostMapping("/invoice")
    public SalesInvoice createSalesInvoice(@RequestBody SalesInvoice salesInvoice) {
        return salesService.createSalesInvoice(salesInvoice);
    }

    @PostMapping("/return")
    public SalesInvoice createSalesReturn(@RequestBody SalesInvoice salesReturn) {
        return salesService.createSalesReturn(salesReturn);
    }

    @PostMapping("/handle-rejections")
    public List<SalesInvoice> handleRejectedItems(@RequestBody Map<String, Integer> rejectedItems) {
        return salesService.handleRejectedItems(rejectedItems);
    }
}