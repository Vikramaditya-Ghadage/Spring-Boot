package com.code.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.code.demo.model.SalesInvoice;

import java.util.List;

public interface SalesInvoiceRepository extends JpaRepository<SalesInvoice, Long> {
    List<SalesInvoice> findByItemCodeOrderByIdAsc(String itemCode);
    List<SalesInvoice> findByTypeOrderByIdAsc(String itemCode);
}